/**
 * Created by Alex on 12/8/15.
 */
var platform = {
	// platform: 'iOS',
	platform: 'Android',
};

module.exports = platform;