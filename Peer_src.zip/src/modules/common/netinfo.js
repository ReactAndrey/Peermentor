/**
 * Created by Alex on 12/8/15.
 */
var netinfo = {

	
};

module.exports = netinfo;