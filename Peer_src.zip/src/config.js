/**
 * Created by Alex on 12/8/15.
 */
var CONFIG = {
    FIREBASE: {
      URL: 'https://1to1-mentor-staging.firebaseio.com',
      KEY: '6Pp7LOOpAF5eDO8Mwv1DebkREZCMXUN3N0GhfvMq' // staging firebase key
      // URL: 'https://1-to-1-mentor-prod.firebaseio.com', // new prod
      // KEY: 'BnGxUQOROyw3pZBPUkqMHcaOwNbabcHkzZKndZh1' // new prod firebase key
    },

    MODULES_ROOT: 'shared_assets/js/modules/',
    // ROOT_URL: 'http://localhost:9000/',
    // ROOT_URL_MENTOR: 'http://single.1to1mentor.org/platformapi/',
    ROOT_URL: 'http://50.116.60.106:9001/', // staging
    ROOT_URL_MENTOR: 'http://www.inq-staging.com/platformapi/',
    // ROOT_URL: 'http://54.187.17.80:9000/', // production
    // ROOT_URL_MENTOR: 'https://www.mentor1to1.org/platformapi/',

   
};
module.exports = CONFIG;